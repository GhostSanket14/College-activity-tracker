package com.GhostSanket14.CollegeActivityportfolio.DTO;

import com.GhostSanket14.CollegeActivityportfolio.Model.HeadLoginData;
import com.GhostSanket14.CollegeActivityportfolio.Model.MemberLoginData;

import jakarta.persistence.Id;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class MemberLoginDataDTO {
	
	@NotNull
	int MemberPrn;
	@NotEmpty(message="Please Enter club associated with Member")
	String ClubAssociated;
	
	public MemberLoginData to() {
		return MemberLoginData.builder()
				.MemberPrn(this.MemberPrn)
				.ClubAssociated(this.ClubAssociated)
				.build();
	}
}