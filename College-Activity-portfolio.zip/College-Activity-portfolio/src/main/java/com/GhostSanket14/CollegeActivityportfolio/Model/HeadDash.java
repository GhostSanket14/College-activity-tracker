package com.GhostSanket14.CollegeActivityportfolio.Model;

import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class HeadDash {
	@Id
	int HDprnNo;
	String HDName;
	String HDDepartment;
	String HDPosition;
	int HDAge;
	String HDacademicYear;
	int HDroll;
	String HDpass;
	String HDemailPersonal;
	String HDemailCollege;
	String HDdateOfBirth;
	long HDmobileNo;
	
	String NameOfClubHeIsHeadOf; // We will put name of club he is head of. (will do this using List of head given by admin)
	@CreationTimestamp
	Date createdHeadDash;
	@UpdateTimestamp
	Date updatedHeadDash;
}