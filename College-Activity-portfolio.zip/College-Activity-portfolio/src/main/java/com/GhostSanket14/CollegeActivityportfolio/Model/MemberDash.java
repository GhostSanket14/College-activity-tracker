package com.GhostSanket14.CollegeActivityportfolio.Model;

import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MemberDash{
	
	@Id
	int MDprnNo;
	String MDName;
	String MDDepartment;
	String MDPosition;
	int MDAge;
	String MDacademicYear;
	int MDroll;
	String MDpass;
	String MDemailPersonal;
	String MDemailCollege;
	String MDdateOfBirth;
	long MDmobileNo;
	
	@CreationTimestamp
	Date createdMemDash;
	@UpdateTimestamp
	Date updatedMemDash;
	
}