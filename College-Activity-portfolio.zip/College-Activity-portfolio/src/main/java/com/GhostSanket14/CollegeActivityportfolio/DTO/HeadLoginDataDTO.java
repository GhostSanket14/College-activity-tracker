package com.GhostSanket14.CollegeActivityportfolio.DTO;

import com.GhostSanket14.CollegeActivityportfolio.Model.HeadLoginData;

import jakarta.persistence.Id;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class HeadLoginDataDTO {
	
	@NotNull
	int HeadPrn;
	@NotEmpty(message="Please Enter club associated with Head")
	String ClubAssociated;
	
	public HeadLoginData to() {
		return HeadLoginData.builder()
				.HeadPrn(this.HeadPrn)
				.ClubAssociated(this.ClubAssociated)
				.build();
	}
}