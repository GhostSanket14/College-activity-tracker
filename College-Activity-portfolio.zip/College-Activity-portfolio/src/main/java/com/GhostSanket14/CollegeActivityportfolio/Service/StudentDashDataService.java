package com.GhostSanket14.CollegeActivityportfolio.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.GhostSanket14.CollegeActivityportfolio.DTO.StudentDashDTO;
import com.GhostSanket14.CollegeActivityportfolio.Model.StudentDash;
import com.GhostSanket14.CollegeActivityportfolio.Repository.StudentDashDataRepo;

@Service
public class StudentDashDataService {

	@Autowired
	StudentDashDataRepo studentDashDataRepo;
	
	// [DASH- STUDENT]
	// If pass & prn user gave(Or we saved in react while login) matches with data present in dash info. Only then we will fetch.
	public StudentDash fetchDashData(int prnNO, String pass) {
		StudentDash stdDash=studentDashDataRepo.findById(prnNO).orElse(null);
		if(stdDash.getSDprnNo()==prnNO && stdDash.getSDpass().equals(pass)) {
			return stdDash;
		}
		return null;
	}

	public void editDashData(StudentDash sd) {
		// If old data exist and its password matches with pass given by user. We will update.
		// But if only PRN match but not the password. we will simply do nothing.
		if(studentDashDataRepo.existsById(sd.getSDprnNo())) {
		StudentDash crossMatching=studentDashDataRepo.findById(sd.getSDprnNo()).orElse(null);
			if(crossMatching.getSDprnNo()==sd.getSDprnNo() && crossMatching.getSDpass().equals(sd.getSDpass())) {
				studentDashDataRepo.save(sd);
			}
		} // Only if PRN no is very new, we will save it was new.  
		else {
		studentDashDataRepo.save(sd);
		}
	}
}