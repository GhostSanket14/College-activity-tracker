package com.GhostSanket14.CollegeActivityportfolio.DTO;

import com.GhostSanket14.CollegeActivityportfolio.Model.HeadDash;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder 
public class HeadDashDTO {
	
	
	int HDprnNo;
	String HDName;
	String HDDepartment;
	String HDPosition;
	int HDAge;
	String HDacademicYear;
	int HDroll;
	String HDpass;
	String HDemailPersonal;
	String HDemailCollege;
	String HDdateOfBirth;
	long HDmobileNo;
	
	public HeadDash to() {
		return HeadDash.builder()
				.HDprnNo(HDprnNo)
				.HDName(HDName)
				.HDDepartment(HDDepartment)
				.HDPosition(HDPosition)
				.HDAge(HDAge)
				.HDacademicYear(HDacademicYear)
				.HDroll(HDroll)
				.HDpass(HDpass)
				.HDemailPersonal(HDemailPersonal)
				.HDemailCollege(HDemailCollege)
				.HDdateOfBirth(HDdateOfBirth)
				.HDmobileNo(HDmobileNo)
				.build();
	}
}