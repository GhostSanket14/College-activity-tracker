package com.GhostSanket14.CollegeActivityportfolio.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.GhostSanket14.CollegeActivityportfolio.DTO.StudentLoginDataDTO;
import com.GhostSanket14.CollegeActivityportfolio.Model.AdminLoginData;
import com.GhostSanket14.CollegeActivityportfolio.Model.HeadLoginData;
import com.GhostSanket14.CollegeActivityportfolio.Model.StudentLoginData;
import com.GhostSanket14.CollegeActivityportfolio.Repository.AdminRepo;
import com.GhostSanket14.CollegeActivityportfolio.Repository.HeadLoginRepo;
import com.GhostSanket14.CollegeActivityportfolio.Repository.StudentAdminLoginRepo;

@Service
public class AdminLoginDataService {

	@Autowired
	AdminRepo adminRepo;
	@Autowired
	StudentAdminLoginRepo studentAdminLoginRepo; 
	@Autowired
	HeadLoginRepo headLoginRepo;
	
	public AdminLoginData createAdmin(AdminLoginData adminLoginData) {
		return adminRepo.save(adminLoginData);
	}

	public boolean verifyLogin(int id, String password) {
		AdminLoginData ald=adminRepo.findById(id).orElse(null); // TIP- use 'orElse' after 'findById' this will give us 'object'
		if(id==ald.getId() && password.equals(ald.getPasswordAdmin())) { // and not 'Optional<object>'
			return true;
		}
		return false;
	
	}

	public StudentLoginData createStudent(StudentLoginData studentLoginData) {
		return studentAdminLoginRepo.save(studentLoginData);
	}

	// This will  verify if the student exists in the data given by admin. After this he will be directed to dashboard.
	// -1 will be returned for the user that dont exist.
	public StudentLoginData verify(int prnNo, int studPass) {
		StudentLoginData verifiedStud= studentAdminLoginRepo.findById(prnNo).orElse(null);
		if(prnNo==verifiedStud.getStudentPrn() && studPass==Integer.parseInt(verifiedStud.getStudentPass())) {
			return verifiedStud;
		}else {
			verifiedStud.setStudentPrn(-1);
			verifiedStud.setStudentPass("-1");
			return verifiedStud;
		}
	}

	// If old pass match. Only then password will be changed. Else we will return -1 as PRN and PASS.
	public StudentLoginData changePass(int prnNo, int studOldPass, String studNewPass) {
		StudentLoginData verifiedStud= studentAdminLoginRepo.findById(prnNo).orElse(null);
		if(prnNo==verifiedStud.getStudentPrn() && studOldPass==Integer.parseInt(verifiedStud.getStudentPass())) {
			verifiedStud.setStudentPass(studNewPass);
			studentAdminLoginRepo.save(verifiedStud);
			return verifiedStud;
		}else {
			verifiedStud.setStudentPrn(-1);
			verifiedStud.setStudentPass("-1");
			return verifiedStud;
		}
	}
	
	// Here admin will tell who is Head.
	public HeadLoginData createHead(HeadLoginData headLoginData) {
		return headLoginRepo.save(headLoginData);
	}

	public HeadLoginData verifyHead(int prnNo) {
		HeadLoginData hld=new HeadLoginData();
		
		if(headLoginRepo.existsById(prnNo)) {
		hld=headLoginRepo.findById(prnNo).orElse(null);
		return hld;
		}else {
			hld.setHeadPrn(-1); // If he is not head, we will return -1.
			return hld;
		}
		
	}
}