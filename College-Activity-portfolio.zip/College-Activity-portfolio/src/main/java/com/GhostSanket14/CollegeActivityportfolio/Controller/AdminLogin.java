package com.GhostSanket14.CollegeActivityportfolio.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.GhostSanket14.CollegeActivityportfolio.DTO.AdmniLoginDataDTO;
import com.GhostSanket14.CollegeActivityportfolio.DTO.HeadLoginDataDTO;
import com.GhostSanket14.CollegeActivityportfolio.DTO.StudentLoginDataDTO;
import com.GhostSanket14.CollegeActivityportfolio.Model.AdminLoginData;
import com.GhostSanket14.CollegeActivityportfolio.Model.HeadLoginData;
import com.GhostSanket14.CollegeActivityportfolio.Model.StudentLoginData;
import com.GhostSanket14.CollegeActivityportfolio.Service.AdminLoginDataService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/admin")
public class AdminLogin { // ID- 302 , PASS- 2001

	@Autowired
	AdminLoginDataService adminLoginDataService;
	
	// This is where we will fill the Login verification data of the admin.
	@PostMapping("/adminLoginData")
	public AdminLoginData adminLoginData(@RequestBody @Valid AdmniLoginDataDTO alDTO) {
		return adminLoginDataService.createAdmin(alDTO.to());
	}
	// http://localhost:8080/adminLogin?id=__&password=___    <- This is how we pass URL.
	@GetMapping("/adminLogin")
	public boolean adminLogin(@RequestParam("id") int id, @RequestParam("password") String password) {
		return adminLoginDataService.verifyLogin(id, password);
	}
	
	// This is where we will fill the Login verification data of the student.
	@PostMapping("/studentLoginData")
	public StudentLoginData studentLoginData(@RequestBody @Valid StudentLoginDataDTO atdDTO) {
		return adminLoginDataService.createStudent(atdDTO.to());
	}
	
	// This is where we will fill the Login verification data of the head. Which is PRN and Name of Club.
	// He will login and his prn and pass will be in 'StudentLoginData'. But if a user selects 'Head' in login option.
	// We will use this to verify if he is a user, before logging him in as head. 
	// (Basically 2 API's 1 student Login, 1 head verification. ).
	@PostMapping("/headLoginData")
	public HeadLoginData headLoginData(@RequestBody @Valid HeadLoginDataDTO hldDTO) {
		return adminLoginDataService.createHead(hldDTO.to());
	}
	
}