package com.GhostSanket14.CollegeActivityportfolio.DTO;

import java.util.Date;

import com.GhostSanket14.CollegeActivityportfolio.Model.StudentDash;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
public class StudentDashDTO { 
	
// PLZ dont put @AllArgsConstructor @NoArgsConstructor in DTO. 
// I just wasted entire day on this.
	
	@NotNull
	int SDprnNo;
	String SDName;
	String SDDepartment;
	String SDPosition;
	int SDAge;
	String SDacademicYear;
	int SDroll;
	String SDpass;
	String SDemailPersonal;
	String SDemailCollege;
	String SDdateOfBirth;
	long SDmobileNo;
	
	public StudentDash to() {
		return StudentDash.builder()
				.SDprnNo(this.SDprnNo)
				.SDName(this.SDName)
				.SDDepartment(this.SDDepartment)
//				.SDPosition(this.SDPosition)  // Later we will figure out how to assign this.
				.SDAge(this.SDAge)
				.SDacademicYear(this.SDacademicYear)
				.SDroll(this.SDroll)
				.SDpass(this.SDpass)
				.SDemailPersonal(this.SDemailPersonal)
				.SDemailCollege(this.SDemailCollege)
				.SDdateOfBirth(this.SDdateOfBirth)
				.SDmobileNo(this.SDmobileNo)
				.build();
	}
// StudentDash model. JSON format
	
//	{
//	  	"SDprnNo": 22120046,
//		"SDName": "Sanket Hodage",
//		"SDDepartment": "IT",
//		"SDPosition": "Head",
//		"SDAge": 22,
//		"SDacademicYear": "2023-2024",
//		"SDroll": 432040,
//		"SDpass": 141414,
//		"SDemailPersonal": "sanketghinchanal@gmail.com",
//		"SDemailCollege": "sanket.22120046@viit.ac.in",
//		"SDdateOfBirth": "14-01-2001",
//		"SDmobileNo": 8007505448
//	}
}