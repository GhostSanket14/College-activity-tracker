package com.GhostSanket14.CollegeActivityportfolio.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.GhostSanket14.CollegeActivityportfolio.DTO.HeadDashDTO;
import com.GhostSanket14.CollegeActivityportfolio.DTO.StudentDashDTO;
import com.GhostSanket14.CollegeActivityportfolio.Model.HeadDash;
import com.GhostSanket14.CollegeActivityportfolio.Model.HeadLoginData;
import com.GhostSanket14.CollegeActivityportfolio.Model.StudentDash;
import com.GhostSanket14.CollegeActivityportfolio.Model.StudentLoginData;
import com.GhostSanket14.CollegeActivityportfolio.Service.AdminLoginDataService;
import com.GhostSanket14.CollegeActivityportfolio.Service.HeadDashDataService;
import com.GhostSanket14.CollegeActivityportfolio.Service.MemberDashDataService;
import com.GhostSanket14.CollegeActivityportfolio.Service.StudentDashDataService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/student")
public class StudentLogin {
	// Login and Password & password change will be same for every user.
	// Based on what option user selects while, login in. He will be directed to, to Student, Head or member dashboard.
	
	
	@Autowired
	AdminLoginDataService adminLoginDataService;
	@Autowired
	StudentDashDataService studDashDataService;
	@Autowired
	HeadDashDataService headDashDataService;
	@Autowired
	MemberDashDataService memberDashDataService;

	// [1] Student verify. This will verify if the user exists or not. If yes then he will be taken to dashboard.
	@GetMapping("/loginVerify")
	public StudentLoginData loginVerify(@RequestParam("prn") int prnNo, @RequestParam("pass") int studPass ){
		return adminLoginDataService.verify(prnNo, studPass);
	}

	
	// [2] Head Verify. (First we will check in loginVerify, and we will check here to see if he is Head.)
	@GetMapping("/verifyHead")
	public HeadLoginData verifyHead(@RequestParam("prn") int prnNo) {
		return adminLoginDataService.verifyHead(prnNo);
	}
	// [2.2] Enter members data.

	// [#] When front end sees user exist and is first ever login, then change the password. Also while normal password change.
	@PostMapping("/changePass")
	public StudentLoginData changePass(@RequestParam("prn") int prnNo,
										@RequestParam("passo") int studOldPass, 
										@RequestParam("passn") String studNewPass) {
		return adminLoginDataService.changePass(prnNo, studOldPass, studNewPass);
	}
	
	
	// DASHBOARDS:
	// [STUDENT]
	// API- Populate student dashboard. As soon as login is verified.(above 1st API).
	@GetMapping("/fetchStudDashboard")
	public StudentDash fetchDanboardStudent(@RequestParam("prn") int prnNO, @RequestParam("pass") String pass) {
		 return studDashDataService.fetchDashData(prnNO, pass);
	}
	@PostMapping("/enterStudDashboard")
	public void enterDanboardStudent(@RequestBody @Valid StudentDashDTO sdDTO) {
		 studDashDataService.editDashData(sdDTO.to());
	}
	
	// [Head]
	@GetMapping("/fetchHeadDashboard")
	public HeadDash fetchDashboardHead(@RequestParam("prn") int prnNo, @RequestParam("pass") String pass) {
		 return headDashDataService.fetchHead(prnNo, pass);
	}
	@PostMapping("/enterHeadDashboard")
	public void enterDanboardHead(@RequestBody @Valid HeadDashDTO sdDTO) {
		 headDashDataService.createHead(sdDTO.to());
	}	
	
}