package com.GhostSanket14.CollegeActivityportfolio.Model;

import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class HeadLoginData {
	@Id
	int HeadPrn;

	String ClubAssociated;
	
	@CreationTimestamp
	Date DateCreated;
	@UpdateTimestamp
	Date DateUpdated;
}