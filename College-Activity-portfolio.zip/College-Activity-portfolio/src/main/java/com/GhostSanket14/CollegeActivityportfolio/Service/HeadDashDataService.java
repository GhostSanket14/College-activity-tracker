package com.GhostSanket14.CollegeActivityportfolio.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.GhostSanket14.CollegeActivityportfolio.Model.HeadDash;
import com.GhostSanket14.CollegeActivityportfolio.Model.HeadLoginData;
import com.GhostSanket14.CollegeActivityportfolio.Model.StudentDash;
import com.GhostSanket14.CollegeActivityportfolio.Repository.HeadDashDataRepo;
import com.GhostSanket14.CollegeActivityportfolio.Repository.HeadLoginRepo;

@Service
public class HeadDashDataService {

	@Autowired
	HeadDashDataRepo headDashDataRepo;
	@Autowired
	HeadLoginRepo headLoginRepo;
	
	public HeadDash fetchHead(int prnNo, String pass) {
		HeadDash hdDash=headDashDataRepo.findById(prnNo).orElse(null);
		if(hdDash.getHDprnNo()==prnNo && hdDash.getHDpass().equals(pass)) {
			return hdDash;
		}
		return null;
	}
	
	// We will create a head and also assign him his group. Which we will get from Admin's 'HeadLoginData'.
	public void createHead(HeadDash headDash) {
		if(headDashDataRepo.existsById(headDash.getHDprnNo())) {
			HeadDash crossMatching=headDashDataRepo.findById(headDash.getHDprnNo()).orElse(null);
			if(crossMatching.getHDprnNo()==headDash.getHDprnNo() && crossMatching.getHDpass().equals(headDash.getHDpass())) {
				HeadLoginData hld=headLoginRepo.findById(headDash.getHDprnNo()).orElse(null);
				headDash.setNameOfClubHeIsHeadOf(hld.getClubAssociated());
				headDashDataRepo.save(headDash);
			}
		} // Only if PRN no is very new, we will save it was new.  
		else {
			HeadLoginData hld=headLoginRepo.findById(headDash.getHDprnNo()).orElse(null);
			headDash.setNameOfClubHeIsHeadOf(hld.getClubAssociated());
			headDashDataRepo.save(headDash);			
		}
	}
}