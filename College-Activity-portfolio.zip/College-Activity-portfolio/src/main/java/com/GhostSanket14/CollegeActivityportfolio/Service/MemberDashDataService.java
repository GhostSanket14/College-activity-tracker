package com.GhostSanket14.CollegeActivityportfolio.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.GhostSanket14.CollegeActivityportfolio.Model.MemberDash;
import com.GhostSanket14.CollegeActivityportfolio.Model.StudentDash;
import com.GhostSanket14.CollegeActivityportfolio.Repository.MemberDashDataRepo;

@Service
public class MemberDashDataService {

	@Autowired
	MemberDashDataRepo memberDashDataRepo;

	public MemberDash fetchDashData(int prnNo, String pass) {
		MemberDash mdDash=memberDashDataRepo.findById(prnNo).orElse(null);
		if(mdDash.getMDprnNo()==prnNo && mdDash.getMDpass().equals(pass)) {
			return mdDash;
		}
		return null;
	}

	public void createMember(MemberDash md) {

		if(memberDashDataRepo.existsById(md.getMDprnNo())) {
		MemberDash crossMatching=memberDashDataRepo.findById(md.getMDprnNo()).orElse(null);
			if(crossMatching.getMDprnNo()==md.getMDprnNo() && crossMatching.getMDpass().equals(md.getMDpass())) {
				memberDashDataRepo.save(md);
			}
		}  
		else {
			memberDashDataRepo.save(md);
		}		
	}
}