package com.GhostSanket14.CollegeActivityportfolio.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.GhostSanket14.CollegeActivityportfolio.Repository.MemberDashDataRepo;

@Service
public class MemberDashDataService {

	@Autowired
	MemberDashDataRepo memberDashDataRepo;
	
	
}