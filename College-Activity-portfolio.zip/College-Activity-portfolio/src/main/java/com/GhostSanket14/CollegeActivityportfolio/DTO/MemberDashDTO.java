package com.GhostSanket14.CollegeActivityportfolio.DTO;

import java.util.Date;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.GhostSanket14.CollegeActivityportfolio.Model.HeadDash;
import com.GhostSanket14.CollegeActivityportfolio.Model.MemberDash;

import jakarta.persistence.Id;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder 
public class MemberDashDTO {
	
	
	@Id
	int MDprnNo;
	String MDName;
	String MDDepartment;
	String MDPosition;
	int MDAge;
	String MDacademicYear;
	int MDroll;
	String MDpass;
	String MDemailPersonal;
	String MDemailCollege;
	String MDdateOfBirth;
	long MDmobileNo;
	
	public MemberDash to() {
		return MemberDash.builder()
				.MDprnNo(this.MDprnNo)
				.MDName(this.MDName)
				.MDDepartment(this.MDDepartment)
				.MDPosition(this.MDPosition)
				.MDAge(this.MDAge)
				.MDacademicYear(this.MDacademicYear)
				.MDroll(this.MDroll)
				.MDpass(this.MDpass)
				.MDemailPersonal(this.MDemailPersonal)
				.MDemailCollege(this.MDemailCollege)
				.MDdateOfBirth(this.MDdateOfBirth)
				.MDmobileNo(this.MDmobileNo)
				.build();
	}
}